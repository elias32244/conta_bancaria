import * as read from "readline-sync";
import { colors } from "./util/Colors";
import { ContaCorrente } from "./model/ContaCorrente";
import { ContaPoupanca } from "./model/ContaPoupanca";
import { ContaController } from "./controller/ContaController";

export function main() {

    let opcao: number;
    const tiposContas = ["Conta Corrente", "Conta Poupança"];
    const contas = new ContaController();

    do {

        console.log(colors.bg.black + colors.fg.yellow +
"*****************************************************\n" +
"                BANCO DO BRAZIL COM Z\n" +
"*****************************************************" + colors.reset);

        console.log(colors.fg.yellow +
"\n1 - Criar Conta" +
"\n2 - Listar todas as Contas" +
"\n3 - Buscar Conta por Numero" +
"\n4 - Atualizar Dados da Conta" +
"\n5 - Apagar Conta" +
"\n6 - Sacar" +
"\n7 - Depositar" +
"\n8 - Transferir valores entre Contas" +
"\n9 - Sair\n" + colors.reset);

        console.log(colors.bg.black + colors.fg.yellow +
"*****************************************************" + colors.reset);

        opcao = read.questionInt(colors.fg.yellow + "Entre com a opção desejada: " + colors.reset);
        console.log();

        switch (opcao) {

            case 1:
                console.log(colors.fg.yellow + "Criar Conta\n" + colors.reset);

                let agencia = read.questionInt("Número da Agência: ");
                let titular = read.question("Nome do Titular: ");
                let tipo = read.keyInSelect(tiposContas, "Tipo da Conta: ") + 1;
                let saldo = read.questionFloat("Saldo Inicial (R$): ");

                if (tipo === 1) {
                    let limite = read.questionFloat("Limite da Conta (R$): ");
                    contas.cadastrar(new ContaCorrente(contas.gerarNumero(), agencia, tipo, titular, saldo, limite));

                } else {
                    let aniversario = read.questionInt("Dia do Aniversário da Conta: ");
                    contas.cadastrar(new ContaPoupanca(contas.gerarNumero(), agencia, tipo, titular, saldo, aniversario));
                }
                break;

            case 2:
                contas.listarTodas();
                break;

            case 3:
                let numero = read.questionInt("Digite o número da Conta: ");
                contas.procurarPorNumero(numero);
                break;

            case 4:
                console.log(colors.fg.yellow + "Atualizar Dados da Conta\n" + colors.reset);

                numero = read.questionInt("Digite o número da Conta: ");
                let conta = contas.buscarNaCollection(numero);

                if (conta != null) {

                    agencia = read.questionInt("Número da Agência: ");
                    titular = read.question("Nome do Titular: ");
                    tipo = conta.tipo;
                    saldo = read.questionFloat("Saldo (R$): ");

                    if (tipo === 1) {
                        let limite = read.questionFloat("Limite da Conta (R$): ");
                        contas.atualizar(new ContaCorrente(numero, agencia, tipo, titular, saldo, limite));
                    } else {
                        let aniversario = read.questionInt("Dia do Aniversário da Conta: ");
                        contas.atualizar(new ContaPoupanca(numero, agencia, tipo, titular, saldo, aniversario));
                    }

                    console.log(colors.fg.green + "\nConta Atualizada com Sucesso!" + colors.reset);

                } else {
                    console.log(colors.fg.red + `\nA Conta número ${numero} não foi encontrada!` + colors.reset);
                }
                break;

            case 5:
                numero = read.questionInt("Digite o número da Conta: ");
                contas.deletar(numero);
                break;

            case 6:
                numero = read.questionInt("Digite o número da Conta: ");
                let valor = read.questionFloat("Valor do Saque (R$): ");
                contas.sacar(numero, valor);
                break;

            case 7:
                numero = read.questionInt("Digite o número da Conta: ");
                valor = read.questionFloat("Valor do Depósito (R$): ");
                contas.depositar(numero, valor);
                break;

            case 8:
                let origem = read.questionInt("Número da Conta de Origem: ");
                let destino = read.questionInt("Número da Conta de Destino: ");
                valor = read.questionFloat("Valor da Transferência (R$): ");
                contas.transferir(origem, destino, valor);
                break;

            case 9:
                console.log(colors.fg.yellow + "\nObrigado por utilizar o Banco do Brazil com Z!" + colors.reset);
                break;

            default:
                console.log(colors.fg.red + "Opção Inválida!" + colors.reset);
        }

        console.log(colors.fg.yellow + "\nPressione ENTER para continuar..." + colors.reset);
        read.question();

    } while (opcao !== 9);
}

main();
